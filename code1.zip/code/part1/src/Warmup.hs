module Warmup where

{-# OPTIONS_GHC -W #-}  -- Just in case you forgot...

type Pos = (Int, Int)
data Direction = North | South | East | West
  deriving (Eq, Show, Read, Ord)

move :: Direction -> Pos -> Pos
move North (x,y) = (x, y+1)
move West  (x,y) = (x-1, y)
move South (x,y) = (x, y-1)
move East  (x,y) = (x+1, y)
-- complete the definition

moves :: [Direction] -> Pos -> Pos
moves [] a=a
moves [x] a    = move x a
moves (x:xs) a = moves [x] (moves xs a)

-- replace with actual definition of moves, and likewise for the
-- other 'undefined' functions

data Nat = Zero | Succ Nat
  deriving (Eq, Show, Read, Ord)

add :: Nat -> Nat -> Nat
add Zero Zero =Zero 
add Zero (Succ x)= Succ x
add (Succ x) Zero= Succ x
add (Succ x) (Succ y)=Succ(Succ(add x y))

mult :: Nat -> Nat -> Nat
mult Zero _ = Zero
mult _ Zero = Zero
mult (Succ x) (Succ y) = add (mult (Succ x) y) (Succ x)

-- Do not use these to define add/mult!
nat2int :: Nat -> Int
nat2int Zero = 0
nat2int (Succ x)= 1 + nat2int x

int2nat :: Int -> Nat
int2nat 0 = Zero
int2nat 1 = Succ Zero
int2nat x = Succ(int2nat (x-1))


data Tree = Leaf | Node Int Tree Tree
  deriving (Eq, Show, Read, Ord)

insert :: Int -> Tree -> Tree
insert x Leaf = Node x Leaf Leaf
insert x (Node y left right)
  | x==y = Node y left right
  | x<y = Node y (insert x left) right
  | x>y = Node y left (insert x right)

-- The polymorphic variant, to avoid name clashes with the above
data PTree a = PLeaf | PNode a (PTree a) (PTree a)
  deriving (Eq, Show, Read, Ord)

--pinsert :: FIXME  -- uncomment and replace with the proper type of pinsert

singleton :: a -> PTree a  
singleton x = PNode x PLeaf PLeaf 

pinsert :: (Ord a) => a -> PTree a -> PTree a  
pinsert x PLeaf = singleton x  
pinsert x (PNode a left right)   
    | x == a = PNode x left right  
    | x < a  = PNode a (pinsert x left) right  
    | x > a  = PNode a left (pinsert x right)
