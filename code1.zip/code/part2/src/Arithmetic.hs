-- This is a skeleton file for you to edit

module Arithmetic
  (
  showExp,
  evalSimple,
  extendEnv,
  evalFull,
  evalErr,
  showCompact,
  evalEager,
  evalLazy
  )

where

import Definitions

showExp :: Exp -> String
showExp (Cst x)= "("++show x++")"
showExp (Add x y)=("("++showExp x ++"+"++showExp y++")")
showExp (Sub x y)=("("++showExp x ++"-"++showExp y++")")
showExp (Mul x y)=("("++showExp x ++"*"++showExp y++")")
showExp (Div x y)=("("++showExp x ++"`div`"++showExp y++")")
showExp (Pow x y)=("("++showExp x ++"^"++showExp y++")")
showExp _ ="using the standard function error"

evalSimple :: Exp -> Integer
evalSimple (Cst x) =x
evalSimple (Add x y)= evalSimple x + evalSimple y
evalSimple (Sub x y)= evalSimple x - evalSimple y
evalSimple (Mul x y)= evalSimple x * evalSimple y
evalSimple (Div x y)
    | evalSimple y == 0 = error "divisor by 0, prohibit"
    | otherwise = div (evalSimple x) (evalSimple y)
evalSimple (Pow x y)
    | evalSimple x /= evalSimple x = error "evaluation of e1 resulted in an error"
    | evalSimple y < 0 =error "Negative exponent, forbidden"
    | otherwise = evalSimple x ^ evalSimple y
evalSimple _=error "unkonwn expression"

extendEnv :: VName -> Integer -> Env -> Env
extendEnv v i e = \x -> if x == v then Just i else e x

evalFull :: Exp -> Env -> Integer
evalFull (Cst x) _ = x
evalFull (Add x y) e =evalFull x e + evalFull y e
evalFull (Sub x y) e =evalFull x e - evalFull y e
evalFull (Mul x y) e =evalFull x e * evalFull y e
evalFull (Div x y) e 
    | evalFull y e == 0 =error "divisor by 0, prohibit"
    | otherwise = div (evalFull x e) (evalFull y e)
evalFull (Pow x y) e 
    | evalFull x e /= evalFull x e = error "evaluation of e1 resulted in an error"
    | evalFull y e <0 =error "Negative exponent, forbidden"
    | otherwise = evalFull x e ^ evalFull y e
evalFull (If{test=test,yes=yes,no=no}) e
    | evalFull test e /= 0 = evalFull yes e
    | otherwise = evalFull no e
evalFull (Var name) e =
    case e name of
        Just value -> value
        Nothing -> error "attempts to access unbound variables"
evalFull (Let var def body) e =
    --let var = evalFull def e in evalFull body e
    let 
        newe = extendEnv var (evalFull def e) e
    in evalFull body newe
evalFull (Sum vname from to body) e=
    let 
        fromv = evalFull from e
        tov = evalFull to e
        updateloop i=
            let newe = extendEnv vname i e in evalFull body newe
    in sum[updateloop i|i<-[fromv .. tov]]


{-
 lookup :: Vname -> Env -> Bool
 lookup vname e
    | e vname == Nothing = False
    | otherwise = True     
-}--I originally wanted to use it in add to consider that a single parameter is not within the scope of the mapping, but after thinking about it, writing it as Exp->Env->Bool would be problematic. Then I thought that there is Varname in the original data. There is no need to write it here.

binaryOpera :: (Integer -> Integer -> Integer) -> Exp -> Exp -> Env -> Either ArithError Integer
binaryOpera op x y e = do
    a <- evalErr x e
    b <- evalErr y e
    return (a `op` b)

evalErr :: Exp -> Env -> Either ArithError Integer
evalErr (Cst x) _ = Right x
{-
evalErr (Add x y) e
    ｜evalErr x e == Right a && evalErr y e == Right b = Right (a+b)
    | evalErr y e == Left err =Left err
    | evalErr x e == Left err =Left err
    | otherwise = Left Eother
-}
{-
evalErr (Add x y) e =
    case (evalErr x e, evalErr y e) of
        (Right a, Right b)-> Right (a+b)
        (Left err ,_)-> Left err
        (_, Left err)-> Left err
-}
{-evalErr (Add x y) e =
    case evalErr x e of
        Right a -> case evalErr y e of
            Right b -> Right (a+b)
            Left err -> Left err
        Left err-> Left err
-}
evalErr (Add x y) e = binaryOpera (+) x y e
{-
evalErr (Sub x y) e =
    case (evalErr x e, evalErr y e) of
        (Right a, Right b)-> Right (a-b)
        (Left err ,_)-> Left err
        (_, Left err)-> Left err
-}
evalErr (Sub x y) e = binaryOpera (-) x y e

evalErr (Mul x y) e = binaryOpera (*) x y e

evalErr (Div x y) e =
    case evalErr x e of
        Right a -> case evalErr y e of
            Right 0 -> Left EDivZero 
            Right b -> Right (div a b)
            Left err -> Left err
        Left err -> Left err

evalErr (Pow x y) e =
    case evalErr x e of
        Left err -> Left err
        Right a-> case evalErr y e of
            Right b-> 
                if b < 0
                    then Left ENegPower
                    else Right (a^b)
            Left err -> Left err
  
{-evalErr (If test yes no) e=
    case(evalErr test e, evalErr yes e ,evalErr no e) of
        (Right a, Right b,Right c)->
            if a /= 0 
                then Right b
                else Right c
        (Left err ,_, _)-> Left err
        (_, Left err, _)-> Left err  
        (_, _, Left err)-> Left err 
-}
evalErr (If test yes no) e=
    case evalErr test e of
        Right 0 -> case evalErr no e of
            Right a -> Right a
            Left err -> Left err
        Right _ -> case evalErr yes e of
            Right c -> Right c
            Left err -> Left err
        Left err -> Left err

evalErr (Var vname) e =
    case e vname of
        Just value -> Right value
        Nothing -> Left (EBadVar vname)
evalErr (Let var def body) e =
    case evalErr def e of
        Right a ->
            let newe= extendEnv var a e
            in case evalErr body newe of
                Right b -> Right b
                Left err -> Left err
        Left err -> Left err
evalErr (Sum vname from to body) e =
    case evalErr from e of
        Right a->case evalErr to e of
            Right b->
                let
                    updateloop i acc
                        | i > b =Right acc
                        | otherwise =
                            let newe=extendEnv vname i e
                            in case evalErr body newe of
                                Right c -> updateloop (i+1) (acc+c)
                                Left err-> Left err
                in updateloop a 0
            Left err -> Left err
        Left err -> Left err

-- optional parts (if not attempted, leave them unmodified)

showCompact :: Exp -> String
showCompact = undefined

evalEager :: Exp -> Env -> Either ArithError Integer
evalEager = undefined

evalLazy :: Exp -> Env -> Either ArithError Integer
evalLazy = undefined
